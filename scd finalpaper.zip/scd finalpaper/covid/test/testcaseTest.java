/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author stu
 */
public class testcaseTest {
    
    public testcaseTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of viewreport method, of class testcase.
     */
    @Test
    public void testViewreport() {
        System.out.println("viewreport");
        testcase instance = new testcase();
        instance.viewreport();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of student method, of class testcase.
     */
    @Test
    public void testStudent() {
        System.out.println("student");
        testcase instance = new testcase();
        instance.student();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of facultymember method, of class testcase.
     */
    @Test
    public void testFacultymember() {
        System.out.println("facultymember");
        testcase instance = new testcase();
        instance.facultymember();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of admin method, of class testcase.
     */
    @Test
    public void testAdmin() {
        System.out.println("admin");
        testcase instance = new testcase();
        instance.admin();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
