
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author stu
 */
public class classdb {
  
    String conString = "jdbc:mysql://localhost:3306/positive covid test";
    String username = "root";
    String password = ""; 
    public DefaultTableModel getDataMemory(String Name) {
        DefaultTableModel Memorydm = new DefaultTableModel();
        //Memory
        Memorydm.addColumn("Built-in");
        Memorydm.addColumn("Card");
        //SQL STATEMENT
         String Memory = "SELECT `Built-in`,`Card` FROM `memory` WHERE MobileName='"+Name+"'  ";
        
        
       try {
            Connection con = DriverManager.getConnection(number_of_student ,  );
           //Memory
            Statement Memorycon = con.prepareStatement(Memory);
            ResultSet MemoryRows = Memorycon.executeQuery(Memory);
            //LOOP THRU GETTING ALL VALUES
            while (MemoryRows.next()) {
                //GET VALUES OF frequency
                 String internal = MemoryRows.getString(1);
                String Card = MemoryRows.getString(2);
                

                Memorydm.addRow(new String[]{internal, Card});
            }
            return Memorydm;
                
            }catch (Exception ex) {
            ex.printStackTrace();
            Logger.getLogger(classdb.class.getName()).log(Level.SEVERE, null, ex);
        }

